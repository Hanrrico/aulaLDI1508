<?php
    $servidor = "localhost:3306";
    $user = "root";
    $senha = "";
    $banco = "bdvendas";
    $caminho = mysqli_connect($servidor, $user, $senha, $banco);
?>